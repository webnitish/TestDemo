﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice
{
    class Program
    {
        static void Main(string[] args)
        {
            //sum();
            //multi();
            //modul();
            //div();
            //con();
            //grtNum();
            printEven();
            Console.ReadLine();

            //==while loop
            /*int i = 1;
            while (i <= 5)
            {
                Console.WriteLine(i);
                i++;
                
            }
            Console.ReadLine();
            /*int i = 0;
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i < 5);
            Console.ReadLine();*/

        }

        //01. =======Add three digit number===
        private static void sum()
        {
            int a, b, c, d;
            Console.WriteLine(" Enter first number");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter first number");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter third number");
            c = Convert.ToInt32(Console.ReadLine());

            d = a + b + c;

            Console.WriteLine("Sum = " + d);

        }

        //===multiplication
        private static void multi()
        {
            int x, y, z;
            Console.WriteLine("Enter first name");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter first name");
            y = Convert.ToInt32(Console.ReadLine());

            z = x * y;
            Console.WriteLine("multi = " + z);
        }

        //03=====modulus
        private static void modul()
        {
            int x, y, z;
            Console.WriteLine("Enter first number");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number");
            y = Convert.ToInt32(Console.ReadLine());

            z = x % y;
            Console.WriteLine("Modulus = " + z);
        }
        //04 -===division
        private static void div(){
            int x, y, z, rem;
            Console.WriteLine("Enter divident number");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter divisor number");
            y = Convert.ToInt32(Console.ReadLine());

            z = x / y;
            rem = x % y;
            Console.WriteLine("Quotient = " + z + "rem = " + rem);

        }
        //05 concatenatjion
        private static void con()
        {
            string x, y, z, a;
            Console.WriteLine("Enter your first name");
            x = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter your middle name");
            y = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter you last name");
            z = Convert.ToString(Console.ReadLine());

            a = x + y + z;
            Console.WriteLine("your name: " + a);
        }
        //06 ===find greater numbr
        private static void grtNum()
        {
            int a, b;
            Console.WriteLine("enter first number");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter second number");
            b = Convert.ToInt32(Console.ReadLine());
            if (a > b)
            {
                Console.WriteLine("First Number is Greater than second number");
            }
            else
            {
                Console.WriteLine("second number is greater than first number");
            }
        }
        
        private static void printEven()
        {
            for(int i = 1; i <= 20; i++)
                if(i%2 != 0)
                {
                    Console.WriteLine(i);
                }
        }
    }
}
